clear all;
clc;

somePerimeter = EllipsePer(6, 3)