clear all;
clc;

P = EllipsePer(6, 3)